# Power BI Dashboard Build Guide
**Prepared by Oyindamola Rufai**

## Import
1. Open Power BI Desktop.
2. Select Home → Get data → Text/CSV.
3. Choose `clean_dataset.csv`, preview it, and select Transform Data.
4. In Power Query, check column names, remove duplicates using the unique record key, set date/number/text types, and select Close & Apply.
5. Rename the imported table to `RetailOrders`.
6. Open `PowerBI_DAX_Measures.dax` and create each measure using Modeling → New measure. Paste one expression at a time.

## Model
Use RetailOrders as the fact table at order-line grain. Create DimDate, DimProduct (ProductID and Category), DimCustomer (CustomerID), DimRegion and DimChannel. Connect each dimension one-to-many to RetailOrders using unique keys. Ensure the date table covers the complete order date range and mark it as the date table.

## Report pages
**Page 1 — Sales & Profit Overview:** total sales, total profit, profit margin, orders, average order value; monthly sales/profit trend; sales by region. **Page 2 — Category & Product Performance:** sales, profit and margin by category; top/bottom products; discount versus margin scatter plot; loss-making order count. **Page 3 — Channel & Returns:** sales/profit by channel, return rate by category and channel, payment method mix, slicers for date, region, category and channel.

## Design tips
Use a consistent 16:9 page, light background, dark navy headings, one accent colour, clear units, descriptive titles and slicers for date, department/category, region and segment. Add a small note: “Synthetic portfolio dataset; not actual company records.”
