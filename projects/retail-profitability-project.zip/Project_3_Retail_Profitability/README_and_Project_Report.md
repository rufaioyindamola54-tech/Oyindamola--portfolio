# Retail Sales and Profitability Analysis

**Prepared by Oyindamola Rufai**

## 1. Business Context
Harbor & Pine Retail is a fictional omnichannel retailer selling electronics, home goods, fashion, beauty, groceries and sports products through online, physical-store and marketplace channels. Management wants to understand sales growth, profitability and regional/category performance.

## 2. Problem Statement and Objectives
Leaders can see sales totals but need to understand what is driving profit, where discounts are eroding margin, which categories and regions perform best, and how returns affect results. Objectives: analyse sales and profit; compare categories, channels and regions; evaluate discounts and returns; and recommend practical actions to improve profitable growth.

## 3. Dataset
This project uses an original, generated synthetic dataset with 8,000 records. It contains no real customer or patient records. The generated data is designed for portfolio analysis and should not be represented as actual company data.

## 4. Data Cleaning (Excel / Power Query)
1. Convert order records to an Excel Table named `RetailOrders`. 2. Check OrderID blanks and duplicates; retain one valid row per order line according to the defined grain. 3. Set OrderDate to Date, Quantity to Whole Number, and price/cost/sales/profit fields to Decimal/Currency. 4. In Power Query, trim and clean text columns and standardise category, region, channel and status values. 5. Validate Quantity > 0, UnitPrice and UnitCost >= 0, DiscountRate between 0 and 1. 6. Recalculate SalesAmount as Quantity × UnitPrice × (1 − DiscountRate), and Profit as SalesAmount − Quantity × UnitCost; compare to supplied fields. 7. Flag negative profit rather than deleting it. 8. Review returned/cancelled orders separately; do not assume every return is a full refund unless transaction-level refund data exists.

## 5. Exploratory Data Analysis in Excel
The workbook includes a structured data table, KPI and segment summary sheets, charts, an Excel Formula Guide with ready-to-use formulas, and a PivotTable Guide showing the exact fields to place in Rows, Columns and Values. To build interactive PivotTables, select a cell in the Clean_Data table and choose Insert → PivotTable.

## 6. Deeper Analysis
Compare revenue, profit and margin by category, region and channel. Analyse discount bands against profit margin and identify loss-making order lines. Review month-level sales and profit trends. Use `=CORREL(RetailOrders[DiscountRate],RetailOrders[ProfitMargin])` as an exploratory association; discounts may be related to product mix and demand, so it is not a causal estimate. Compare returns by category and channel, and investigate high-sales/low-margin segments.

## 7. Power BI Data Model
Use RetailOrders as the fact table at order-line grain. Create DimDate, DimProduct (ProductID and Category), DimCustomer (CustomerID), DimRegion and DimChannel. Connect each dimension one-to-many to RetailOrders using unique keys. Ensure the date table covers the complete order date range and mark it as the date table.

## 8. DAX Measures
See `PowerBI_DAX_Measures.dax` for the complete measures and comments.

## 9. Dashboard Design
**Page 1 — Sales & Profit Overview:** total sales, total profit, profit margin, orders, average order value; monthly sales/profit trend; sales by region. **Page 2 — Category & Product Performance:** sales, profit and margin by category; top/bottom products; discount versus margin scatter plot; loss-making order count. **Page 3 — Channel & Returns:** sales/profit by channel, return rate by category and channel, payment method mix, slicers for date, region, category and channel.

## 10. Key Findings
- Orders analysed: 8,000; unique customers: 4,438.
- Total sales: 3,440,059.34 (dataset currency units).
- Total profit: 1,069,436.50.
- Overall profit margin: 31.1%.
- Returned orders: 470 (5.9%). These are results from the generated portfolio dataset, not real company performance.

## 11. Recommendations
1. Protect margin by reviewing discount levels for categories with high sales but weak profit. 2. Prioritise inventory and campaigns around categories and regions with both strong demand and healthy margins. 3. Investigate return reasons in categories with elevated return rates before changing policies. 4. Review marketplace fees and fulfilment costs separately if those data become available. 5. Track profit margin and contribution, not sales alone. Risks: reducing discounts may reduce volume; return-rate comparisons need consistent order and refund definitions; cost data should include shipping, payment fees and overhead before final pricing decisions.

## 12. Executive Summary
Harbor & Pine's synthetic retail dataset contains 8,000 order records across six product categories and three sales channels. The analysis evaluates sales, profit, margin, discounts, returns and regional performance. Generated data totals 3,440,059.34 in sales and 1,069,436.50 in profit, with an overall margin of 31.1%. The project demonstrates an end-to-end workflow for identifying profitable growth opportunities; figures are portfolio results from synthetic data.

## 13. Portfolio README and Career Write-up
I completed an end-to-end retail sales and profitability analysis for Harbor & Pine Retail using an original synthetic dataset of 8,000 order records. I cleaned order data in Excel, analysed sales and profit by category, channel and region, evaluated discount and return patterns, and prepared Power BI DAX measures and dashboard specifications. The recommendations focus on profitable growth rather than sales volume alone.

### CV bullet
Built an 8,000-row synthetic retail analytics project using Excel and Power BI; analysed sales, profit, margin, discounts, returns and regional/category performance; developed DAX KPIs and business recommendations.

## Limitations and Next Steps
The dataset is synthetic and currency units are illustrative. It contains order-level cost estimates but excludes full operating expenses, shipping, tax, payment fees and detailed refund transactions. The analysis cannot establish why customers returned items or prove that discounts caused margin changes. Real deployment requires reconciled finance and inventory records.

## Files
- `Analysis_Workbook.xlsx`: cleaned dataset, summary tables, charts, Excel formulas and PivotTable build guide.
- `clean_dataset.csv`: Power BI import-ready data.
- `PowerBI_DAX_Measures.dax`: DAX measure definitions.
- `README_and_Project_Report.md`: project report, workflow, findings and portfolio description.
- `PowerBI_Dashboard_Build_Guide.md`: exact Power BI build steps and visual plan.
