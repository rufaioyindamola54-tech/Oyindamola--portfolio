# Power BI Dashboard Build Guide
**Prepared by Oyindamola Rufai**

## Import
1. Open Power BI Desktop.
2. Select Home → Get data → Text/CSV.
3. Choose `clean_dataset.csv`, preview it, and select Transform Data.
4. In Power Query, check column names, remove duplicates using the unique record key, set date/number/text types, and select Close & Apply.
5. Rename the imported table to `HospitalVisits`.
6. Open `PowerBI_DAX_Measures.dax` and create each measure using Modeling → New measure. Paste one expression at a time.

## Model
Create a star schema. HospitalVisits is the fact table (one row per visit). Create DimDate from VisitDate, DimDepartment from Department, DimDoctor from DoctorID, and DimPatient from PatientID. Relate each dimension's unique key one-to-many to HospitalVisits. Use single-direction filtering from dimensions to fact. Ensure VisitID is unique; PatientID can repeat across visits.

## Report pages
**Page 1 — Operations Overview:** total visits, unique patients, average wait, average satisfaction, readmission rate; visits by month; average wait by department. **Page 2 — Waiting-Time Bottlenecks:** average and median wait by department, shift and weekday; department × shift matrix with conditional formatting; long-wait rate; slicers for date, severity and department. **Page 3 — Patient Experience & Outcomes:** satisfaction distribution, satisfaction vs wait scatter plot, readmission rate by severity/department, average bed wait and consultation time. Add a note that this is synthetic, non-clinical portfolio data.

## Design tips
Use a consistent 16:9 page, light background, dark navy headings, one accent colour, clear units, descriptive titles and slicers for date, department/category, region and segment. Add a small note: “Synthetic portfolio dataset; not actual company records.”
