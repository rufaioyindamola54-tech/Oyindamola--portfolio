# Hospital Operations and Patient Experience Analysis

**Prepared by Oyindamola Rufai**

## 1. Business Context
CedarBridge Private Hospital Group is a fictional multi-department hospital network. Operations leaders want to understand patient flow, waiting-time bottlenecks, satisfaction and 30-day readmission patterns without exposing real patient information.

## 2. Problem Statement and Objectives
The operations team needs to identify where patients wait longest, how shift and department affect throughput, whether longer waits are associated with lower satisfaction, and which visit groups show higher readmission rates. Objectives: measure wait-time performance; compare departments, shifts and weekdays; examine patient experience; and provide practical operational recommendations.

## 3. Dataset
This project uses an original, generated synthetic dataset with 6,500 records. It contains no real customer or patient records. The generated data is designed for portfolio analysis and should not be represented as actual company data.

## 4. Data Cleaning (Excel / Power Query)
1. Convert the visit data to an Excel Table named `HospitalVisits`. 2. Check VisitID uniqueness and blanks; remove duplicate VisitIDs only after reviewing them. 3. Set VisitDate to Date, ArrivalHour and minute fields to Whole Number, and satisfaction to Whole Number. 4. In Power Query, trim/clean text columns and standardise department/shift labels. 5. Filter impossible values such as negative waiting times, consultation times below zero, satisfaction outside 1–5, and dates outside the reporting period. 6. Check missing PatientID separately; do not invent patient identity. 7. Confirm the readmission flag is Yes/No and document its synthetic definition. 8. Close & Load.

## 5. Exploratory Data Analysis in Excel
The workbook includes a structured data table, KPI and segment summary sheets, charts, an Excel Formula Guide with ready-to-use formulas, and a PivotTable Guide showing the exact fields to place in Rows, Columns and Values. To build interactive PivotTables, select a cell in the Clean_Data table and choose Insert → PivotTable.

## 6. Deeper Analysis
Compare average and median wait by department, shift and weekday; median is useful because extreme waits can distort the average. Calculate the correlation between WaitMinutes and PatientSatisfaction with `=CORREL(HospitalVisits[WaitMinutes],HospitalVisits[PatientSatisfaction])`. Treat it as association, not proof that waiting causes dissatisfaction. Compare readmission rates by severity and department, but do not interpret them as clinical quality without case-mix adjustment. Create a heat map using department by shift and conditional formatting.

## 7. Power BI Data Model
Create a star schema. HospitalVisits is the fact table (one row per visit). Create DimDate from VisitDate, DimDepartment from Department, DimDoctor from DoctorID, and DimPatient from PatientID. Relate each dimension's unique key one-to-many to HospitalVisits. Use single-direction filtering from dimensions to fact. Ensure VisitID is unique; PatientID can repeat across visits.

## 8. DAX Measures
See `PowerBI_DAX_Measures.dax` for the complete measures and comments.

## 9. Dashboard Design
**Page 1 — Operations Overview:** total visits, unique patients, average wait, average satisfaction, readmission rate; visits by month; average wait by department. **Page 2 — Waiting-Time Bottlenecks:** average and median wait by department, shift and weekday; department × shift matrix with conditional formatting; long-wait rate; slicers for date, severity and department. **Page 3 — Patient Experience & Outcomes:** satisfaction distribution, satisfaction vs wait scatter plot, readmission rate by severity/department, average bed wait and consultation time. Add a note that this is synthetic, non-clinical portfolio data.

## 10. Key Findings
- Total encounters: 6,500; unique pseudonymous patient IDs: 3,438.
- Average wait: 73.0 minutes; median wait: 72 minutes.
- Visits with waits above 60 minutes: 4,400 (67.7%).
- Average patient satisfaction: 4.02 out of 5.
- Synthetic 30-day readmission flag rate: 6.4%. This is a generated operational metric, not a clinical benchmark.

## 11. Recommendations
1. Review staffing coverage in departments and shifts with the longest median waits. 2. Introduce a simple queue escalation rule for visits approaching the 60-minute threshold. 3. Separate bed-wait time from clinician wait so the responsible operational team is clear. 4. Collect consistent post-visit feedback and review low-satisfaction themes. 5. Monitor readmission patterns by severity and case mix before drawing quality conclusions. Risks: changing staffing without demand forecasts can increase cost; wait-time comparisons can be misleading if patient acuity differs; readmission data needs clinical validation.

## 12. Executive Summary
CedarBridge's synthetic hospital dataset contains 6,500 visit records across six departments. The analysis measures waiting times, consultation and bed delays, patient satisfaction and a synthetic 30-day readmission indicator. Average wait is 73.0 minutes, and 67.7% of visits exceed 60 minutes. The project demonstrates how Excel and Power BI can help operations teams identify bottlenecks and monitor patient experience. The data is generated for portfolio use and must not be treated as real clinical evidence.

## 13. Portfolio README and Career Write-up
I developed an end-to-end hospital operations analysis for CedarBridge Private Hospital Group using an original synthetic dataset of 6,500 visits. I cleaned and validated encounter data, compared waiting times by department, shift and weekday, explored satisfaction and readmission patterns, and prepared a Power BI star schema with DAX KPIs. The work translates operational data into practical patient-flow recommendations.

### CV bullet
Analysed 6,500 synthetic hospital visits using Excel and Power BI; measured waiting-time performance, department and shift bottlenecks, patient satisfaction and readmission indicators; designed DAX KPIs and operational recommendations.

## Limitations and Next Steps
All records and outcomes are synthetic; no real patient information is used. The readmission flag is generated for demonstration and is not clinically derived or suitable for medical decision-making. Patient IDs are pseudonymous and repeated visits are simulated. Real analysis would require governance approval, secure handling, clinical definitions, case-mix adjustment and validation with hospital stakeholders.

## Files
- `Analysis_Workbook.xlsx`: cleaned dataset, summary tables, charts, Excel formulas and PivotTable build guide.
- `clean_dataset.csv`: Power BI import-ready data.
- `PowerBI_DAX_Measures.dax`: DAX measure definitions.
- `README_and_Project_Report.md`: project report, workflow, findings and portfolio description.
- `PowerBI_Dashboard_Build_Guide.md`: exact Power BI build steps and visual plan.
