# Telecom Customer Churn Analysis

**Prepared by Oyindamola Rufai**

## 1. Business Context
NexaTel Telecommunications is a fictional subscription provider serving residential customers across several service plans. Leadership wants to understand why customers leave and where retention activity could protect recurring subscription revenue.

## 2. Problem Statement and Objectives
The retention team needs a clear view of churn levels, customer segments associated with higher churn, recurring charges linked to churned accounts, and practical actions that can be prioritised. Objectives: quantify churn; compare contract, tenure, payment and service segments; identify customers for further review; and turn the findings into a retention plan.

## 3. Dataset
This project uses an original, generated synthetic dataset with 7,200 records. It contains no real customer or patient records. The generated data is designed for portfolio analysis and should not be represented as actual company data.

## 4. Data Cleaning (Excel / Power Query)
1. Convert the range to an Excel Table named `TelecomData` (Ctrl+T). 2. Check CustomerID blanks and duplicates with `=COUNTBLANK(TelecomData[CustomerID])` and `=SUMPRODUCT((TelecomData[CustomerID]<>"")/COUNTIF(TelecomData[CustomerID],TelecomData[CustomerID]&""))-COUNTA(TelecomData[CustomerID])` (or use Data → Remove Duplicates after keeping a backup). 3. Set MonthlyCharges and TotalCharges to Decimal; TenureMonths to Whole Number. 4. Use Power Query Home → Transform data; select text columns → Transform → Format → Trim and Clean. 5. Replace empty numeric values only after checking the business meaning; do not silently turn missing charges into zero. 6. Validate tenure 0–72, charges greater than or equal to zero, and Churn values Yes/No. 7. Close & Load to a clean table.

## 5. Exploratory Data Analysis in Excel
The workbook includes a structured data table, KPI and segment summary sheets, charts, an Excel Formula Guide with ready-to-use formulas, and a PivotTable Guide showing the exact fields to place in Rows, Columns and Values. To build interactive PivotTables, select a cell in the Clean_Data table and choose Insert → PivotTable.

## 6. Deeper Analysis
Segment churn by contract, tenure group, internet service and payment method. Compare monthly charges for churned and retained customers. Use `=CORREL(TelecomData[TenureMonths],TelecomData[MonthlyCharges])` for an exploratory association, not a causal claim. The included risk band is a transparent rule-based indicator generated for this synthetic dataset; it is not a trained or validated predictive model. Use a PivotTable with Contract in Rows and Churn in Columns to compare rates.

## 7. Power BI Data Model
Start with one fact-like customer table, `TelecomCustomers`, because each row represents one customer. Keep CustomerID unique. For a more advanced version, create DimContract, DimPaymentMethod and DimDate only if you introduce dated snapshots; do not create artificial relationships that add no analytical value.

## 8. DAX Measures
See `PowerBI_DAX_Measures.dax` for the complete measures and comments.

## 9. Dashboard Design
**Page 1 — Executive Overview:** cards for Total Customers, Churned Customers, Churn Rate, Retention Rate and Churned Monthly Charges at Risk; column chart for churn rate by contract; line/column chart for churn rate by tenure group; slicers for Contract, InternetService and PaymentMethod. **Page 2 — Customer Risk:** bar chart for high-risk customers by segment, table of customer IDs and risk band, churn by tenure group and payment method. **Page 3 — Revenue & Services:** monthly charges by churn status, churn rate by InternetService and TechSupport, and revenue-at-risk by contract.

## 10. Key Findings
- Dataset contains 7,200 customers.
- Churned customers: 2,924 (40.6%).
- Retained customers: 4,276.
- Average monthly charge: 67.78.
- Monthly charges associated with churned accounts: 199,618.05. This is a historical monthly-charge proxy, not confirmed lost profit or future revenue.

## 11. Recommendations
1. Prioritise month-to-month customers for proactive renewal conversations; measure offer acceptance and 90-day retention. 2. Review first-year customer journeys and contact customers before likely cancellation points. 3. Investigate technical support and service experience for high-churn segments. 4. Test targeted retention offers with a control group before scaling. 5. Track churn rate, retained revenue and campaign cost monthly. Risks: discounts can reduce margin, and a rule-based risk band can create false positives; validate any targeting approach before operational use.

## 12. Executive Summary
NexaTel's synthetic customer dataset contains 7,200 customer records. The analysis measures churn, compares contract and tenure segments, and estimates the monthly subscription charges associated with churned accounts. The observed churn rate in this generated dataset is 40.6%. These results demonstrate an end-to-end workflow from data validation and Excel analysis to Power BI reporting and retention recommendations. Because the data is synthetic, the figures are portfolio demonstration results rather than real company performance.

## 13. Portfolio README and Career Write-up
I built an end-to-end customer churn analysis for NexaTel Telecommunications using an original synthetic dataset. I cleaned and validated customer records in Excel, explored churn patterns across contract and tenure segments, and prepared Power BI measures and dashboard specifications. The project demonstrates how analysis can help a retention team focus customer outreach and monitor recurring-charge exposure.

### CV bullet
Created a 7,200-row synthetic telecom churn project using Excel and Power BI; cleaned customer data, analysed churn by contract and tenure, developed DAX KPIs, and translated findings into customer-retention recommendations.

## Limitations and Next Steps
Synthetic records are not evidence of real market behaviour. The dataset represents one customer-level snapshot and does not contain a true monthly event history. Revenue-at-risk uses monthly charges for churned customers and is not equivalent to lost profit, lifetime value or a forecast. The risk band is illustrative and requires validation against real outcomes.

## Files
- `Analysis_Workbook.xlsx`: cleaned dataset, summary tables, charts, Excel formulas and PivotTable build guide.
- `clean_dataset.csv`: Power BI import-ready data.
- `PowerBI_DAX_Measures.dax`: DAX measure definitions.
- `README_and_Project_Report.md`: project report, workflow, findings and portfolio description.
- `PowerBI_Dashboard_Build_Guide.md`: exact Power BI build steps and visual plan.
