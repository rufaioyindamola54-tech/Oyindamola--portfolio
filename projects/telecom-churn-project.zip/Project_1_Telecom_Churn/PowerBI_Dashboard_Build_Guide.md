# Power BI Dashboard Build Guide
**Prepared by Oyindamola Rufai**

## Import
1. Open Power BI Desktop.
2. Select Home → Get data → Text/CSV.
3. Choose `clean_dataset.csv`, preview it, and select Transform Data.
4. In Power Query, check column names, remove duplicates using the unique record key, set date/number/text types, and select Close & Apply.
5. Rename the imported table to `TelecomCustomers`.
6. Open `PowerBI_DAX_Measures.dax` and create each measure using Modeling → New measure. Paste one expression at a time.

## Model
Start with one fact-like customer table, `TelecomCustomers`, because each row represents one customer. Keep CustomerID unique. For a more advanced version, create DimContract, DimPaymentMethod and DimDate only if you introduce dated snapshots; do not create artificial relationships that add no analytical value.

## Report pages
**Page 1 — Executive Overview:** cards for Total Customers, Churned Customers, Churn Rate, Retention Rate and Churned Monthly Charges at Risk; column chart for churn rate by contract; line/column chart for churn rate by tenure group; slicers for Contract, InternetService and PaymentMethod. **Page 2 — Customer Risk:** bar chart for high-risk customers by segment, table of customer IDs and risk band, churn by tenure group and payment method. **Page 3 — Revenue & Services:** monthly charges by churn status, churn rate by InternetService and TechSupport, and revenue-at-risk by contract.

## Design tips
Use a consistent 16:9 page, light background, dark navy headings, one accent colour, clear units, descriptive titles and slicers for date, department/category, region and segment. Add a small note: “Synthetic portfolio dataset; not actual company records.”
